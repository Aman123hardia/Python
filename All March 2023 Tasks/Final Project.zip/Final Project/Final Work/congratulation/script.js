
$(window).on("load",function(){
	
	setTimeout(function(){$('.done').addClass("drawn");},500)
	
});

function myForm(){
    location.replace("http://127.0.0.1:5500/index.html")  
}