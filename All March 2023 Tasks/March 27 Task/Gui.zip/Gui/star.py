import turtle             
my_pen = turtle.Turtle()      
for i in range(50):
 my_pen.forward(50)           
 my_pen.right(144)               
 turtle.done()