
# square
# import turtle
# import time
# t=turtle.Turtle()
# t.right(90)
# time.sleep(1)
# t.forward(100)
# time.sleep(1)
# t.right(90)
# time.sleep(1)
# t.forward(100)
# time.sleep(1)
# t.right(90)
# t.forward(100)
# t.right(90)
# t.forward(100)
# t.backward(100)

# turtle.done()
import turtle
import time 
t=turtle.Turtle()
t.left(120)
t.forward(100)
# t.up(90)
t.backward(120)
t.forward(120)
t.left(120)
t.forward(120)
t.backward(40)
t.left(120)
t.forward(90)
# t.backward(60)
# t.right(90)
# t.forward(50)

turtle.done()