import turtle
tu=turtle.Turtle()
for i in range(5):
    tu.forward(140)
    tu.right(160)
