import turtle
for i in range(4):
 turtle.circle(100, 180) #Draws a circle with 180 degrees and 100 pixels radius(a half circle)
 turtle.left(90)
 turtle.forward(200)

turtle.done()


# import turtle
# for i in range(9):
#  turtle.circle(0, 45) #Draws a circle with 180 degrees and 100 pixels radius(a half circle)
#  turtle.left(90)
#  turtle.forward(200)

# turtle.done()


