
def fun1(firstName):       

 def fun2(lastName):
    print("Hello",firstName,lastName)
    global x
    x=fun1
 fun2("Mourya")
fun1('Aman')

x("shubham")