from connection import data as connection
from create import * 

# useDatabase()
createDatabase()