#using colored statement
# from rich import print

# print("[bold red] hello")
# print("[itelic green] hello")
# print("[underline yellow] hello")
# print("")



# report of any object 
# from rich import inspect
# from rich.color import Color
# color = Color.parse("red")
# inspect(color, methods=True)


# working with console
from rich.console import Console
console = Console()

