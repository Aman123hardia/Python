import mysql.connector
import requests,json
mydatabase=mysql.connector.connect(
    host="localhost",
    user='root',
    password='Tout@53',
    database='mydatabase'
)

data=requests.get('https://dummyjson.com/users')
dataList=json.loads(data.text)
database=mydatabase.cursor()

for index in range(len(dataList['users'])):
    if index<=20:
     for key in dataList['users'][index]:
        if key=='id':
            print(dataList['users'][index][key])
            database.executemany("INSERT INTO Amna(id) VALUES (%s)" % dataList['users'][index][key])


database.close()