import mysql.connector
import requests,json
mydatabase=mysql.connector.connect(
    host="localhost",
    user='root',
    password='Tout@53',
    database='mydatabase'
)

database=mydatabase.cursor()
table=database.execute("create table Employee(id int primary key)")


