import requests
from tabulate import tabulate
import json
from bs4 import BeautifulSoup
url='https://www.livemint.com/news/'
r = requests.get(url)

soup = BeautifulSoup(r.content, 'html.parser')
s = soup.find_all('div', class_='headlineSec')
data=[]
dic=[]
fetch={}
link=[]
for i in s:
 for count,c in enumerate(i.stripped_strings):
   if count == 0 or count== 1 or count ==3:
    dic.append(c)
  
 else:
    link=list(i.find("a").get('href'))
    for i in range(5):
     link.pop(0) 
    str=""
    x=str.join(link)
    r = requests.get(url+x)
    soup = BeautifulSoup(r.content, 'html.parser')
    s = soup.find_all('div', class_='FirstEle')
    des=soup.find('p')
    
    data.append({"headings":dic[0],"Discription":des.text.strip(),"Reading Time":dic[1],"Uploaded Time":dic[2],"Links":url+x})
    link.clear()
    dic.clear()
    
      
with open("json_data.json", "w") as file1:
    file1.write(json.dumps(data ,indent=5))
