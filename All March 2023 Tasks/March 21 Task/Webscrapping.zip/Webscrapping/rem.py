papa = "/news/world-europe-65021987"
app = "app is important"
print(papa.lstrip('world-europe-65021987'))