class MyClass:     # create class with class name
    x = 5


print(MyClass)
# __main__ is the name of the environment where top-level code is run. 
# “Top-level code” is the first user-specified Python module that starts running.
