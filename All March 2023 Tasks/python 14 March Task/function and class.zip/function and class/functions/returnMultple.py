def wish():                                      #parameter function with return key
 return 2,3,4

print(wish())