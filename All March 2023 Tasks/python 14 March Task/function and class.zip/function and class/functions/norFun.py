def builtFunction():
    x=3
    print(id(x))                             # built in functions id
    print(type(x))                          # built in functions type

builtFunction()


# def greeting():                               # user defined function 
#     print("Good Morning....")
    
# greeting()




