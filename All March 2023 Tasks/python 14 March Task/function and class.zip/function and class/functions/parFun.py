
# def wish(name):                                      #parameter function without return key
#  print("Hello",name,"Good Morning")

# print(wish(input("what is your name = "))



def wish(name):                                      #parameter function with return key
 return "Hello",name,"Good Morning"

print(type(wish(input("what is your name = "))))           #tuple return type