def working(a,b):
 print(a,b)

working(2,3,4) 
# The number of arguments and position of arguments must be matched. If we change the
# order then result may be changed.
# If we change the number of arguments then we will get error syntax error invalid syntax.