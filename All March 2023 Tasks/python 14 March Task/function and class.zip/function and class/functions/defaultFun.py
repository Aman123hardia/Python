def wish(name="Guest"):
 print("Hello",name,"Good Morning")


wish()
wish(name="Aman")
wish("Aman")

# After default arguments we should not take non default arguments