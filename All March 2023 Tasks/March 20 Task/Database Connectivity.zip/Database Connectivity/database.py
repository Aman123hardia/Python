# from mysql.connector import (connection)

# cnx = connection.MySQLConnection(user='root', password='Tout@53',
#                                  host='127.0.0.1'
#                                  )
# cnx.close()
# import mysql.connector
# import params

# mydb = mysql.connector.connect(host=params["127.0.0.1"],
#                                 user=params["root"],
#                                 password=params["Tout@53"],
#                                 database=params["mysql"]
# )

# print(mydb)
import pymysql

connection = pymysql.connect(user='root', password='Tout@53', host='127.0.0.1',  database='mysql')
cursor = connection.cursor()
# query = ("SELECT * FROM myTable")
# cursor.execute(query)
# for item in cursor:
#   print(item)